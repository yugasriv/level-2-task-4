# ⬡ FormForge

**Complex Form Validation & Dynamic DOM Manipulation SPA**  
*Cognifyz Technologies Internship — Level 2, Task 4*

---

## 🌟 Live Demo

> Open `index.html` in any browser — zero dependencies, zero build step.

---

## 📌 What This Project Demonstrates

| Requirement | Implementation |
|---|---|
| Complex form validation | 12-rule composable `Validator` engine with real-time feedback |
| Password strength meter | 6-point scoring with animated bars and per-rule checklist |
| Dynamic DOM updates | Live field states, tag inputs, animated counters, chart manipulation |
| Client-side routing | Hash-based SPA router with auth guards and page transitions |

---

## 🗂 Project Structure

```
formforge/
├── index.html          # SPA entry point
├── css/
│   └── main.css        # Premium dark UI design system (~700 lines)
└── js/
    ├── validator.js    # Rule-based validation engine
    ├── dom.js          # DOM utilities, toast system, state store
    ├── router.js       # Client-side hash router
    ├── pages.js        # All 5 page renderers + form logic
    └── app.js          # Bootstrap: routes, guards, globals
```

---

## ✨ Features

### 🧠 Validator Engine (`validator.js`)
- **12 built-in rules**: `required`, `email`, `phone`, `url`, `minLength`, `maxLength`, `username`, `match`, `noSpaces`, `lettersOnly`, `numeric`, `checked`
- `validateField(value, rules[])` — runs rules in order, returns first failure
- `validateForm(schema)` — validates an entire form object at once
- `bindField(input, rules, options)` — attaches live `input`/`blur` listeners with visual feedback
- `passwordStrength(password)` — returns `{ score, label, colorClass, checks }` for 6 criteria

### ⚡ DOM Utilities (`dom.js`)
- `DOM.toast.success/error/warn/info()` — animated 4-type toast notification system
- `DOM.updateStrengthUI()` — renders strength bars, label, and rule checklist live
- `DOM.createTagsInput()` — keyboard-driven tag input (Enter/comma/space to add, Backspace to remove)
- `DOM.animateCount()` — smooth eased number animation with `IntersectionObserver`
- `DOM.store` — localStorage + sessionStorage abstraction with activity logging
- `DOM.debounce()` — utility for rate-limiting inputs

### 🗺️ Router (`router.js`)
- Hash-based routing (`#/`, `#/register`, `#/login`, `#/profile`, `#/dashboard`)
- `beforeEach` auth guard — redirects unauthenticated users with toast message
- `afterEach` hook — activity logging per navigation
- Page transition animations via CSS class injection
- `data-route` link interception — no full-page reloads

### 📄 Pages (`pages.js`)
| Route | Description |
|---|---|
| `/` | Landing with animated counters and feature grid |
| `/register` | Full registration form: name, username, email, phone, role, skills tags, password + confirm |
| `/login` | Email + password login with localStorage user matching |
| `/profile` | View/edit profile, change password (with strength meter), delete account |
| `/dashboard` | Metrics grid, activity log, interactive bar chart, quick actions |

---

## 🎨 Design System

- **Palette**: Deep navy `#080b14` · accent blue `#4f8ef7` · purple `#a78bfa` · green `#34d399`
- **Typography**: [Space Grotesk](https://fonts.google.com/specimen/Space+Grotesk) display · [Inter](https://fonts.google.com/specimen/Inter) body
- **Effects**: Glassmorphism nav · mesh radial gradient background · glow shadows · spring animations
- **Components**: Cards, buttons (primary/ghost/danger), form fields, strength meter, tags input, toasts, skeleton loader

---

## 🚀 Getting Started

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/formforge.git
cd formforge

# Open in browser (no server needed)
open index.html
# or: python3 -m http.server 3000
```

---

## 🧪 Validation Rules Reference

```js
// Usage example
Validator.bindField(input, [
  'required',
  { name: 'minLength', args: [8] },
  { name: 'match', args: [() => otherInput.value, 'passwords'] }
], { msgEl, iconOk, iconErr });
```

---

## 📊 Tech Stack

- **Vanilla JavaScript** (ES6+ IIFEs, closures, async/await)
- **Zero frameworks** — no React, Vue, Angular, or jQuery
- **Zero build tools** — no webpack, Vite, or transpilers
- **CSS Custom Properties** for theming
- **localStorage / sessionStorage** for persistence

---

## 👩‍💻 Author

**Yuga Sri** · B.Tech AI & Data Science · Er. Perumal Manimekalai College of Engineering  
Built as part of the **Cognifyz Technologies Web Development Internship** — Level 2, Task 4.

---

*Made with ⚡ and zero frameworks.*
