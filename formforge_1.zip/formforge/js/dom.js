/**
 * FormForge — DOM Utilities
 * Lightweight reactive DOM manipulation helpers
 */

const DOM = (() => {

  /* ─── SELECTORS ─── */
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

  /* ─── CREATE ELEMENT ─── */
  const el = (tag, attrs = {}, ...children) => {
    const element = document.createElement(tag);
    for (const [key, val] of Object.entries(attrs)) {
      if (key === 'class') element.className = val;
      else if (key === 'html') element.innerHTML = val;
      else if (key === 'text') element.textContent = val;
      else if (key.startsWith('on')) element.addEventListener(key.slice(2), val);
      else element.setAttribute(key, val);
    }
    children.forEach(child => {
      if (typeof child === 'string') element.appendChild(document.createTextNode(child));
      else if (child instanceof Node) element.appendChild(child);
    });
    return element;
  };

  /* ─── RENDER ─── */
  const render = (target, html) => {
    if (typeof target === 'string') target = $(target);
    if (!target) return;
    target.innerHTML = html;
    return target;
  };

  /* ─── APPEND ─── */
  const append = (target, child) => {
    if (typeof target === 'string') target = $(target);
    if (!target) return;
    if (typeof child === 'string') target.insertAdjacentHTML('beforeend', child);
    else target.appendChild(child);
  };

  /* ─── REMOVE ─── */
  const remove = (target) => {
    if (typeof target === 'string') target = $(target);
    target?.parentNode?.removeChild(target);
  };

  /* ─── TOGGLE CLASS ─── */
  const toggle = (target, cls, force) => {
    if (typeof target === 'string') target = $(target);
    target?.classList.toggle(cls, force);
  };

  /* ─── TOAST SYSTEM ─── */
  const toast = (() => {
    const container = () => document.getElementById('toast-container');

    const show = (title, message = '', type = 'info', duration = 4000) => {
      const icons = { success: '✅', error: '❌', warn: '⚠️', info: 'ℹ️' };
      const t = el('div', { class: `toast ${type}` });
      t.innerHTML = `
        <span class="toast-icon">${icons[type]}</span>
        <div class="toast-body">
          <div class="toast-title">${title}</div>
          ${message ? `<div class="toast-msg">${message}</div>` : ''}
        </div>
        <button class="toast-close" aria-label="Close">✕</button>
      `;
      const close = () => {
        t.classList.add('removing');
        t.addEventListener('animationend', () => t.remove(), { once: true });
      };
      t.querySelector('.toast-close').addEventListener('click', close);
      container()?.appendChild(t);
      if (duration > 0) setTimeout(close, duration);
      return t;
    };

    return {
      success: (title, msg, d) => show(title, msg, 'success', d),
      error:   (title, msg, d) => show(title, msg, 'error', d),
      warn:    (title, msg, d) => show(title, msg, 'warn', d),
      info:    (title, msg, d) => show(title, msg, 'info', d),
    };
  })();

  /* ─── PASSWORD STRENGTH UI ─── */
  const renderStrengthMeter = (password) => {
    const { score, label, colorClass, checks } = Validator.passwordStrength(password);
    return { score, label, colorClass, checks };
  };

  const updateStrengthUI = (password, barsEl, labelEl, checksEl) => {
    const { score, label, colorClass, checks } = renderStrengthMeter(password);

    // Update bars
    if (barsEl) {
      $$('.strength-bar', barsEl).forEach((bar, i) => {
        bar.className = 'strength-bar';
        if (i < score) bar.classList.add(colorClass);
      });
    }

    // Update label
    if (labelEl) {
      const colors = { 'active-1': '#f87171', 'active-2': '#fbbf24', 'active-3': '#4f8ef7', 'active-4': '#34d399' };
      labelEl.innerHTML = `
        <span>Password strength</span>
        <span style="color:${colors[colorClass] || '#4b5268'}">${label}</span>
      `;
    }

    // Update checklist
    if (checksEl) {
      const checkMap = {
        length:    '8+ characters',
        uppercase: 'Uppercase letter',
        lowercase: 'Lowercase letter',
        number:    'Number',
        special:   'Special character',
        long:      '12+ characters',
      };
      checksEl.innerHTML = Object.entries(checks).map(([key, passed]) => `
        <div class="rule-item ${passed ? 'passed' : ''}">
          <span class="rule-icon">${passed ? '✓' : '○'}</span>
          <span>${checkMap[key]}</span>
        </div>
      `).join('');
    }

    return { score, label };
  };

  /* ─── TAGS INPUT ─── */
  const createTagsInput = (container, inputEl, onChange) => {
    const tags = new Set();

    const addTag = (val) => {
      const cleaned = val.trim().toLowerCase().replace(/[^a-z0-9\s\-]/g, '');
      if (!cleaned || tags.has(cleaned)) return;
      tags.add(cleaned);

      const tagEl = el('span', { class: 'tag' });
      tagEl.innerHTML = `${cleaned} <span class="tag-remove" data-tag="${cleaned}">×</span>`;
      tagEl.querySelector('.tag-remove').addEventListener('click', () => {
        tags.delete(cleaned);
        tagEl.remove();
        onChange([...tags]);
      });
      container.insertBefore(tagEl, inputEl);
      inputEl.value = '';
      onChange([...tags]);
    };

    inputEl.addEventListener('keydown', (e) => {
      if (['Enter', ',', ' '].includes(e.key)) {
        e.preventDefault();
        addTag(inputEl.value);
      }
      if (e.key === 'Backspace' && !inputEl.value) {
        const lastTag = [...tags].pop();
        if (lastTag) {
          tags.delete(lastTag);
          container.querySelector(`[data-tag="${lastTag}"]`)?.closest('.tag')?.remove();
          onChange([...tags]);
        }
      }
    });

    container.addEventListener('click', () => inputEl.focus());

    return {
      getTags: () => [...tags],
      addTag,
    };
  };

  /* ─── ANIMATE COUNT ─── */
  const animateCount = (el, from, to, duration = 1200, suffix = '') => {
    const start = performance.now();
    const update = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      el.textContent = Math.round(from + (to - from) * eased).toLocaleString() + suffix;
      if (progress < 1) requestAnimationFrame(update);
    };
    requestAnimationFrame(update);
  };

  /* ─── INTERSECTION OBSERVER ─── */
  const onVisible = (elements, callback, options = {}) => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          callback(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, ...options });
    (Array.isArray(elements) ? elements : [elements]).forEach(el => observer.observe(el));
    return observer;
  };

  /* ─── DEBOUNCE ─── */
  const debounce = (fn, delay) => {
    let timer;
    return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
  };

  /* ─── STORE (local state) ─── */
  const store = (() => {
    const state = {
      user: JSON.parse(localStorage.getItem('ff_user') || 'null'),
      sessionLog: JSON.parse(sessionStorage.getItem('ff_log') || '[]'),
    };

    return {
      get: (key) => state[key],
      set: (key, val) => {
        state[key] = val;
        if (key === 'user') localStorage.setItem('ff_user', JSON.stringify(val));
        if (key === 'sessionLog') sessionStorage.setItem('ff_log', JSON.stringify(val));
      },
      clear: () => {
        state.user = null;
        localStorage.removeItem('ff_user');
        sessionStorage.clear();
      },
      logAction: (action) => {
        const log = state.sessionLog || [];
        log.unshift({ action, time: new Date().toISOString() });
        state.sessionLog = log.slice(0, 20);
        sessionStorage.setItem('ff_log', JSON.stringify(state.sessionLog));
      }
    };
  })();

  return { $, $$, el, render, append, remove, toggle, toast, updateStrengthUI, createTagsInput, animateCount, onVisible, debounce, store };
})();
