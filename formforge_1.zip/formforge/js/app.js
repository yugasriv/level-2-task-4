/**
 * FormForge — Application Bootstrap
 * Wires up router, routes, navbar, and global UX.
 */

(function () {
  'use strict';

  /* ─── NAVBAR SCROLL EFFECT ─── */
  window.addEventListener('scroll', () => {
    const nav = document.getElementById('navbar');
    if (nav) nav.classList.toggle('scrolled', window.scrollY > 20);
  }, { passive: true });

  /* ─── MOBILE HAMBURGER ─── */
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.querySelector('.nav-links');
  hamburger?.addEventListener('click', () => {
    navLinks?.classList.toggle('open');
    const isOpen = navLinks?.classList.contains('open');
    hamburger.setAttribute('aria-expanded', isOpen);
  });

  // Close mobile nav on link click
  document.addEventListener('click', (e) => {
    if (e.target.closest('[data-route]') || !e.target.closest('nav')) {
      navLinks?.classList.remove('open');
    }
  });

  /* ─── REGISTER ROUTES ─── */
  Router.register('/',          Pages.home);
  Router.register('/register',  Pages.register);
  Router.register('/login',     Pages.login);
  Router.register('/profile',   Pages.profile,   { requiresAuth: true });
  Router.register('/dashboard', Pages.dashboard, { requiresAuth: true });
  Router.register('*',          Pages.notFound);

  /* ─── AUTH GUARD ─── */
  const authGuard = (path, meta) => {
    if (meta.requiresAuth && !DOM.store.get('user')) {
      DOM.toast.warn('Login Required', 'Create an account or sign in to access that page.');
      Router.navigate('/login');
      return false;
    }
    return true;
  };

  /* ─── AFTER EACH (page analytics logging) ─── */
  const afterEach = (path) => {
    DOM.store.logAction(`navigated to ${path}`);
  };

  /* ─── INIT ROUTER ─── */
  Router.init({ beforeEach: authGuard, afterEach });

  /* ─── GLOBAL KEYBOARD SHORTCUTS ─── */
  document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + K → focus first input on page
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      document.querySelector('.form-input')?.focus();
    }
    // Escape → close mobile nav
    if (e.key === 'Escape') navLinks?.classList.remove('open');
  });

  /* ─── CSS FOR SHAKE ANIMATION ─── */
  const shakeStyle = document.createElement('style');
  shakeStyle.textContent = `
    .shake {
      animation: shakeBtn 0.45s cubic-bezier(.36,.07,.19,.97) both;
    }
    @keyframes shakeBtn {
      10%, 90% { transform: translateX(-2px); }
      20%, 80% { transform: translateX(4px); }
      30%, 50%, 70% { transform: translateX(-5px); }
      40%, 60% { transform: translateX(5px); }
    }
    [data-count-pct] { }
  `;
  document.head.appendChild(shakeStyle);

  console.log('%cFormForge v1.0 — Cognifyz Internship L2T4', 'color:#4f8ef7;font-weight:700;font-size:14px');
  console.log('%cClient-side routing · Form validation · Dynamic DOM', 'color:#8b92a7;font-size:12px');
})();
