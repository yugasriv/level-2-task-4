/**
 * FormForge — Page Renderers
 * Each page returns HTML string + post-render initialization
 */

const Pages = (() => {

  /* ══════════════════════════════════
     HOME PAGE
  ══════════════════════════════════ */
  const home = async () => {
    const html = `
      <section class="hero">
        <div class="hero-content">
          <div class="hero-badge">⬡ Cognifyz · Level 2 · Task 4</div>
          <h1 class="hero-title">
            Forms that <span class="grad">validate</span><br/>
            and<span class="grad"> adapt</span> in real-time.
          </h1>
          <p class="hero-desc">
            FormForge is a production-grade SPA demonstrating complex form validation,
            dynamic DOM manipulation, and client-side routing — built for 
            enterprise-level portfolio impact.
          </p>
          <div class="hero-actions">
            <a href="#/register" data-route="/register" class="btn btn-primary">
              ⚡ Try the Demo
            </a>
            <a href="#/dashboard" data-route="/dashboard" class="btn btn-ghost">
              📊 Dashboard
            </a>
          </div>
          <div class="hero-stats">
            <div class="stat-card">
              <div class="stat-num" data-count="12">0</div>
              <div class="stat-label">Validation Rules</div>
            </div>
            <div class="stat-card">
              <div class="stat-num" data-count="5">0</div>
              <div class="stat-label">SPA Routes</div>
            </div>
            <div class="stat-card">
              <div class="stat-num" data-count="100">0</div>
              <div class="stat-label">% Client-Side</div>
            </div>
          </div>
        </div>

        <div class="hero-visual">
          <div class="hero-card">
            <div class="mini-form-label">Password Strength Engine</div>
            <div class="mini-field" style="background:var(--bg-3);color:var(--text-2)">john.doe@company.com</div>
            <div class="mini-field" style="background:var(--bg-3);color:var(--text-2)">••••••••••••</div>
            <div class="mini-strength">
              <div class="mini-bar fill-1"></div>
              <div class="mini-bar fill-2"></div>
              <div class="mini-bar fill-3"></div>
              <div class="mini-bar fill-4"></div>
            </div>
            <div class="mini-badge">✓ Very Strong Password</div>
            <div style="margin-top:16px;display:grid;grid-template-columns:1fr 1fr;gap:6px">
              <div class="rule-item passed" style="font-size:.72rem"><span>✓</span> 8+ chars</div>
              <div class="rule-item passed" style="font-size:.72rem"><span>✓</span> Uppercase</div>
              <div class="rule-item passed" style="font-size:.72rem"><span>✓</span> Number</div>
              <div class="rule-item passed" style="font-size:.72rem"><span>✓</span> Special char</div>
            </div>
          </div>
        </div>
      </section>

      <section class="features">
        <h2 class="features-title">Everything a senior engineer expects</h2>
        <p class="features-sub">Built on vanilla JS — no frameworks, no shortcuts.</p>
        <div class="features-grid">
          <div class="feature-card">
            <div class="feature-icon-wrap" style="background:rgba(79,142,247,.12)">🧠</div>
            <h3>Composable Validator Engine</h3>
            <p>12 built-in rules, real-time field binding, and schema-level validation with descriptive error messages.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon-wrap" style="background:rgba(52,211,153,.12)">⚡</div>
            <h3>Dynamic DOM Manipulation</h3>
            <p>Live feedback, animated strength meters, tag inputs, count animations, and intersection-triggered reveals.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon-wrap" style="background:rgba(167,139,250,.12)">🗺️</div>
            <h3>Client-Side Router</h3>
            <p>Hash-based SPA routing with auth guards, beforeEach/afterEach hooks, and transition animations.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon-wrap" style="background:rgba(251,191,36,.12)">🔐</div>
            <h3>Password Strength Meter</h3>
            <p>6-point scoring: length, uppercase, lowercase, digits, special characters — with live rule checklist.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon-wrap" style="background:rgba(248,113,113,.12)">💾</div>
            <h3>Persistent State</h3>
            <p>localStorage + sessionStorage integration. Registered users persist across sessions seamlessly.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon-wrap" style="background:rgba(79,142,247,.12)">🍞</div>
            <h3>Toast Notification System</h3>
            <p>Four-tier (success/error/warn/info) animated toast system with auto-dismiss and manual close.</p>
          </div>
        </div>
      </section>
    `;

    setTimeout(() => {
      document.querySelectorAll('[data-count]').forEach(el => {
        DOM.onVisible(el, (node) => {
          DOM.animateCount(node, 0, parseInt(node.dataset.count), 1400,
            node.dataset.count === '100' ? '%' : '+');
        });
      });
    }, 50);

    return html;
  };

  /* ══════════════════════════════════
     REGISTER PAGE
  ══════════════════════════════════ */
  const register = async () => {
    const html = `
      <div class="form-page">
        <div class="form-wrap">
          <div class="form-header">
            <div class="form-icon">📝</div>
            <h1 class="form-title">Create an account</h1>
            <p class="form-subtitle">Already have one? <a href="#/login" data-route="/login">Sign in</a></p>
          </div>

          <div class="form-progress" id="regProgress">
            <div class="progress-step current" data-step="1"></div>
            <div class="progress-step" data-step="2"></div>
            <div class="progress-step" data-step="3"></div>
            <div class="progress-step" data-step="4"></div>
          </div>

          <div class="card" id="regCard">
            <form id="registerForm" novalidate>

              <!-- Full Name -->
              <div class="row">
                <div class="form-group">
                  <label class="form-label" for="firstName">
                    First Name <span class="label-required">*</span>
                  </label>
                  <div class="input-wrap">
                    <input type="text" id="firstName" class="form-input" placeholder="John" autocomplete="given-name"/>
                    <span class="input-icon icon-ok">✓</span>
                    <span class="input-icon icon-err">✕</span>
                  </div>
                  <div class="field-msg" id="firstNameMsg"></div>
                </div>
                <div class="form-group">
                  <label class="form-label" for="lastName">
                    Last Name <span class="label-required">*</span>
                  </label>
                  <div class="input-wrap">
                    <input type="text" id="lastName" class="form-input" placeholder="Doe" autocomplete="family-name"/>
                    <span class="input-icon icon-ok">✓</span>
                    <span class="input-icon icon-err">✕</span>
                  </div>
                  <div class="field-msg" id="lastNameMsg"></div>
                </div>
              </div>

              <!-- Username -->
              <div class="form-group">
                <label class="form-label" for="username">
                  Username <span class="label-required">*</span>
                </label>
                <div class="input-wrap">
                  <input type="text" id="username" class="form-input" placeholder="john_doe99" autocomplete="username"/>
                  <span class="input-icon icon-ok">✓</span>
                  <span class="input-icon icon-err">✕</span>
                </div>
                <div class="field-msg" id="usernameMsg"></div>
              </div>

              <!-- Email -->
              <div class="form-group">
                <label class="form-label" for="email">
                  Email Address <span class="label-required">*</span>
                </label>
                <div class="input-wrap">
                  <input type="email" id="email" class="form-input" placeholder="john@example.com" autocomplete="email"/>
                  <span class="input-icon icon-ok">✓</span>
                  <span class="input-icon icon-err">✕</span>
                </div>
                <div class="field-msg" id="emailMsg"></div>
              </div>

              <!-- Phone -->
              <div class="form-group">
                <label class="form-label" for="phone">Phone Number</label>
                <div class="input-wrap">
                  <input type="tel" id="phone" class="form-input" placeholder="+1 (555) 000-0000" autocomplete="tel"/>
                  <span class="input-icon icon-ok">✓</span>
                  <span class="input-icon icon-err">✕</span>
                </div>
                <div class="field-msg" id="phoneMsg"></div>
              </div>

              <!-- Role -->
              <div class="form-group">
                <label class="form-label" for="role">Role / Occupation</label>
                <select id="role" class="form-select">
                  <option value="">Select your role...</option>
                  <option value="student">Student</option>
                  <option value="developer">Software Developer</option>
                  <option value="data-scientist">Data Scientist / AI Engineer</option>
                  <option value="designer">UI/UX Designer</option>
                  <option value="manager">Product Manager</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <!-- Skills Tags -->
              <div class="form-group">
                <label class="form-label" for="skillsInput">
                  Skills <span style="font-weight:400;color:var(--text-3)">(type + Enter)</span>
                </label>
                <div class="tags-container" id="tagsContainer">
                  <input type="text" id="skillsInput" class="tags-input" placeholder="e.g. Python, ML, React..."/>
                </div>
                <div class="field-msg" id="tagsMsg"></div>
              </div>

              <!-- Password -->
              <div class="form-group">
                <label class="form-label" for="password">
                  Password <span class="label-required">*</span>
                </label>
                <div class="input-wrap">
                  <input type="password" id="password" class="form-input" placeholder="Create a strong password"/>
                  <button type="button" class="toggle-password" data-target="password">👁</button>
                </div>
                <div class="strength-meter">
                  <div class="strength-bars" id="strengthBars">
                    <div class="strength-bar"></div>
                    <div class="strength-bar"></div>
                    <div class="strength-bar"></div>
                    <div class="strength-bar"></div>
                  </div>
                  <div class="strength-label" id="strengthLabel">
                    <span>Password strength</span><span></span>
                  </div>
                  <div class="rules-list" id="rulesList"></div>
                </div>
                <div class="field-msg" id="passwordMsg"></div>
              </div>

              <!-- Confirm Password -->
              <div class="form-group">
                <label class="form-label" for="confirmPassword">
                  Confirm Password <span class="label-required">*</span>
                </label>
                <div class="input-wrap">
                  <input type="password" id="confirmPassword" class="form-input" placeholder="Repeat your password"/>
                  <button type="button" class="toggle-password" data-target="confirmPassword">👁</button>
                  <span class="input-icon icon-ok">✓</span>
                  <span class="input-icon icon-err">✕</span>
                </div>
                <div class="field-msg" id="confirmPasswordMsg"></div>
              </div>

              <!-- Terms -->
              <div class="form-group">
                <div class="checkbox-group">
                  <input type="checkbox" id="terms" class="checkbox-input"/>
                  <label class="checkbox-label" for="terms">
                    I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.
                  </label>
                </div>
                <div class="field-msg" id="termsMsg"></div>
              </div>

              <!-- Submit -->
              <button type="submit" class="btn btn-primary btn-full mt-8" id="registerBtn">
                Create Account →
              </button>

              <div class="divider">or</div>
              <a href="#/login" data-route="/login" class="btn btn-ghost btn-full">
                Sign in to existing account
              </a>

            </form>
          </div>
        </div>
      </div>
    `;

    setTimeout(initRegisterForm, 50);
    return html;
  };

  const initRegisterForm = () => {
    const form = document.getElementById('registerForm');
    if (!form) return;

    // Tags input
    let userTags = [];
    const tagsContainer = document.getElementById('tagsContainer');
    const skillsInput = document.getElementById('skillsInput');
    if (tagsContainer && skillsInput) {
      DOM.createTagsInput(tagsContainer, skillsInput, (tags) => { userTags = tags; });
    }

    // Password toggle
    document.querySelectorAll('.toggle-password').forEach(btn => {
      btn.addEventListener('click', () => {
        const input = document.getElementById(btn.dataset.target);
        input.type = input.type === 'password' ? 'text' : 'password';
        btn.textContent = input.type === 'password' ? '👁' : '🙈';
      });
    });

    // Password strength
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
      passwordInput.addEventListener('input', () => {
        DOM.updateStrengthUI(
          passwordInput.value,
          document.getElementById('strengthBars'),
          document.getElementById('strengthLabel'),
          document.getElementById('rulesList')
        );
        // Re-validate confirm if already touched
        const confirm = document.getElementById('confirmPassword');
        if (confirm?.classList.contains('invalid') || confirm?.classList.contains('valid')) {
          confirm.dispatchEvent(new Event('input'));
        }
        // Update progress
        updateProgress();
      });
    }

    // Bind all fields
    const bindings = {
      firstName:       ['required', { name: 'lettersOnly' }, { name: 'minLength', args: [2] }],
      lastName:        ['required', { name: 'lettersOnly' }, { name: 'minLength', args: [2] }],
      username:        ['required', { name: 'username' }],
      email:           ['required', { name: 'email' }],
      phone:           [{ name: 'phone' }],
    };

    const validators = {};
    for (const [id, rules] of Object.entries(bindings)) {
      const input = document.getElementById(id);
      const msgEl = document.getElementById(`${id}Msg`);
      const wrap = input?.closest('.input-wrap');
      if (!input) continue;
      validators[id] = Validator.bindField(input, rules, {
        msgEl,
        iconOk: wrap?.querySelector('.icon-ok'),
        iconErr: wrap?.querySelector('.icon-err'),
        onValid: () => updateProgress(),
        onInvalid: () => updateProgress(),
      });
    }

    // Password validation
    const pwInput = document.getElementById('password');
    const pwMsg = document.getElementById('passwordMsg');
    validators.password = Validator.bindField(pwInput, [
      'required',
      { name: 'minLength', args: [8] },
    ], { msgEl: pwMsg });

    // Confirm password
    const cpInput = document.getElementById('confirmPassword');
    const cpMsg = document.getElementById('confirmPasswordMsg');
    const cpWrap = cpInput?.closest('.input-wrap');
    validators.confirmPassword = Validator.bindField(cpInput, [
      'required',
      {
        name: 'match',
        args: [() => document.getElementById('password')?.value, 'passwords'],
      },
    ], {
      msgEl: cpMsg,
      iconOk: cpWrap?.querySelector('.icon-ok'),
      iconErr: cpWrap?.querySelector('.icon-err'),
    });

    // Override match rule to use getter
    const origCpValidate = validators.confirmPassword.validate;
    cpInput.addEventListener('input', () => {
      const val = cpInput.value;
      const pwVal = document.getElementById('password')?.value;
      const valid = val === pwVal && val.length > 0;
      cpInput.classList.toggle('valid', valid);
      cpInput.classList.toggle('invalid', !valid && val.length > 0);
      if (cpMsg) {
        cpMsg.textContent = valid || !val.length ? '' : 'Passwords do not match.';
        cpMsg.className = `field-msg ${(!valid && val.length) ? 'error-msg show' : ''}`;
      }
      updateProgress();
    });

    // Progress bar updater
    const updateProgress = () => {
      const fields = ['firstName', 'lastName', 'username', 'email', 'password'];
      const validCount = fields.filter(id => document.getElementById(id)?.classList.contains('valid')).length;
      const steps = document.querySelectorAll('#regProgress .progress-step');
      steps.forEach((step, i) => {
        const threshold = (i + 1) * Math.ceil(fields.length / steps.length);
        step.className = 'progress-step' + (validCount > i * 1.2 ? ' done' : '') + (validCount === i * 1.2 ? ' current' : '');
      });
    };

    // Submit
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let allValid = true;
      for (const [id, v] of Object.entries(validators)) {
        if (!v.validate()) allValid = false;
      }
      const terms = document.getElementById('terms');
      const termsMsg = document.getElementById('termsMsg');
      if (!terms?.checked) {
        allValid = false;
        if (termsMsg) {
          termsMsg.textContent = 'You must accept the terms to continue.';
          termsMsg.className = 'field-msg error-msg show';
        }
      } else if (termsMsg) {
        termsMsg.className = 'field-msg';
      }

      const { score } = Validator.passwordStrength(document.getElementById('password')?.value || '');
      if (score < 2) {
        allValid = false;
        DOM.toast.error('Weak Password', 'Please use a stronger password before continuing.');
      }

      if (!allValid) {
        DOM.toast.error('Form Incomplete', 'Please fix all highlighted errors.');
        // Shake the submit button
        const btn = document.getElementById('registerBtn');
        btn?.classList.add('shake');
        setTimeout(() => btn?.classList.remove('shake'), 500);
        return;
      }

      const user = {
        id: Date.now(),
        firstName: document.getElementById('firstName').value,
        lastName:  document.getElementById('lastName').value,
        username:  document.getElementById('username').value,
        email:     document.getElementById('email').value,
        phone:     document.getElementById('phone').value,
        role:      document.getElementById('role').value,
        skills:    userTags,
        createdAt: new Date().toISOString(),
      };

      DOM.store.set('user', user);
      DOM.store.logAction('registered');
      DOM.toast.success('Account Created! 🎉', `Welcome, ${user.firstName}! Redirecting to your dashboard...`);
      setTimeout(() => Router.navigate('/dashboard'), 1800);
    });
  };

  /* ══════════════════════════════════
     LOGIN PAGE
  ══════════════════════════════════ */
  const login = async () => {
    const html = `
      <div class="form-page">
        <div class="form-wrap">
          <div class="form-header">
            <div class="form-icon">🔐</div>
            <h1 class="form-title">Welcome back</h1>
            <p class="form-subtitle">Don't have an account? <a href="#/register" data-route="/register">Register</a></p>
          </div>
          <div class="card">
            <form id="loginForm" novalidate>
              <div class="form-group">
                <label class="form-label" for="loginEmail">Email Address <span class="label-required">*</span></label>
                <div class="input-wrap">
                  <input type="email" id="loginEmail" class="form-input" placeholder="john@example.com" autocomplete="email"/>
                  <span class="input-icon icon-ok">✓</span>
                  <span class="input-icon icon-err">✕</span>
                </div>
                <div class="field-msg" id="loginEmailMsg"></div>
              </div>

              <div class="form-group">
                <label class="form-label" for="loginPassword">
                  Password <span class="label-required">*</span>
                  <a href="#" style="margin-left:auto;font-size:.78rem;color:var(--accent);text-decoration:none;font-weight:500">Forgot?</a>
                </label>
                <div class="input-wrap">
                  <input type="password" id="loginPassword" class="form-input" placeholder="Your password"/>
                  <button type="button" class="toggle-password" data-target="loginPassword">👁</button>
                </div>
                <div class="field-msg" id="loginPasswordMsg"></div>
              </div>

              <div class="form-group">
                <div class="checkbox-group">
                  <input type="checkbox" id="rememberMe" class="checkbox-input" checked/>
                  <label class="checkbox-label" for="rememberMe">Keep me signed in for 30 days</label>
                </div>
              </div>

              <button type="submit" class="btn btn-primary btn-full mt-8">Sign In →</button>
              <div class="divider">or</div>
              <a href="#/register" data-route="/register" class="btn btn-ghost btn-full">Create new account</a>
            </form>
          </div>

          <div class="field-msg hint-msg show mt-16" style="margin-top:12px;border-radius:8px;padding:10px 14px">
            💡 Use the email you registered with. No account? 
            <a href="#/register" data-route="/register" style="color:var(--accent)">Register first →</a>
          </div>
        </div>
      </div>
    `;

    setTimeout(initLoginForm, 50);
    return html;
  };

  const initLoginForm = () => {
    const form = document.getElementById('loginForm');
    if (!form) return;

    // Toggle password
    document.querySelectorAll('.toggle-password').forEach(btn => {
      btn.addEventListener('click', () => {
        const input = document.getElementById(btn.dataset.target);
        input.type = input.type === 'password' ? 'text' : 'password';
        btn.textContent = input.type === 'password' ? '👁' : '🙈';
      });
    });

    const emailInput = document.getElementById('loginEmail');
    const emailMsg = document.getElementById('loginEmailMsg');
    const emailWrap = emailInput?.closest('.input-wrap');
    Validator.bindField(emailInput, ['required', 'email'], {
      msgEl: emailMsg,
      iconOk: emailWrap?.querySelector('.icon-ok'),
      iconErr: emailWrap?.querySelector('.icon-err'),
    });

    const pwInput = document.getElementById('loginPassword');
    const pwMsg = document.getElementById('loginPasswordMsg');
    Validator.bindField(pwInput, ['required', { name: 'minLength', args: [6] }], { msgEl: pwMsg });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const email = emailInput?.value.trim();
      const password = pwInput?.value;

      if (!email || !password) {
        DOM.toast.error('Missing Fields', 'Please fill in your email and password.');
        return;
      }

      const saved = DOM.store.get('user');
      if (!saved || saved.email.toLowerCase() !== email.toLowerCase()) {
        DOM.toast.error('Account Not Found', 'No account with that email. Try registering.');
        return;
      }

      DOM.store.logAction('logged in');
      DOM.toast.success('Signed In!', `Welcome back, ${saved.firstName}!`);
      setTimeout(() => Router.navigate('/dashboard'), 1200);
    });
  };

  /* ══════════════════════════════════
     PROFILE PAGE
  ══════════════════════════════════ */
  const profile = async () => {
    const user = DOM.store.get('user');
    if (!user) {
      Router.navigate('/login');
      return '';
    }

    const initials = `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase();
    const skillsHtml = (user.skills || []).map(s =>
      `<span class="profile-tag">${s}</span>`
    ).join('') || '<span style="color:var(--text-3);font-size:.82rem">No skills added</span>';

    const html = `
      <div class="profile-page">
        <div class="profile-header">
          <div class="avatar-wrap">
            <div class="avatar" id="avatarEl">${initials}</div>
            <div class="avatar-badge">✓</div>
          </div>
          <div class="profile-info">
            <h2>${user.firstName} ${user.lastName}</h2>
            <p>${user.email} ${user.phone ? '· ' + user.phone : ''}</p>
            <div class="profile-tags">${skillsHtml}</div>
          </div>
          <div style="margin-left:auto;display:flex;gap:8px;flex-wrap:wrap">
            <button class="btn btn-ghost btn-sm" id="editProfileBtn">✏️ Edit</button>
            <button class="btn btn-danger btn-sm" id="logoutBtn">Sign Out</button>
          </div>
        </div>

        <div class="profile-sections">
          <!-- Account Info -->
          <div class="card">
            <div class="section-title">Account Information</div>
            <form id="profileForm" novalidate>
              <div class="row">
                <div class="form-group">
                  <label class="form-label">First Name</label>
                  <input type="text" id="pFirstName" class="form-input" value="${user.firstName}" disabled/>
                </div>
                <div class="form-group">
                  <label class="form-label">Last Name</label>
                  <input type="text" id="pLastName" class="form-input" value="${user.lastName}" disabled/>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" id="pEmail" class="form-input" value="${user.email}" disabled/>
              </div>
              <div class="form-group">
                <label class="form-label">Role</label>
                <select id="pRole" class="form-select" disabled>
                  <option value="">Select...</option>
                  <option value="student" ${user.role === 'student' ? 'selected' : ''}>Student</option>
                  <option value="developer" ${user.role === 'developer' ? 'selected' : ''}>Software Developer</option>
                  <option value="data-scientist" ${user.role === 'data-scientist' ? 'selected' : ''}>Data Scientist / AI Engineer</option>
                  <option value="designer" ${user.role === 'designer' ? 'selected' : ''}>UI/UX Designer</option>
                  <option value="manager" ${user.role === 'manager' ? 'selected' : ''}>Product Manager</option>
                  <option value="other" ${user.role === 'other' ? 'selected' : ''}>Other</option>
                </select>
              </div>
              <div id="profileSaveArea" style="display:none;margin-top:4px">
                <button type="submit" class="btn btn-primary btn-sm">Save Changes</button>
                <button type="button" class="btn btn-ghost btn-sm" id="cancelEditBtn">Cancel</button>
              </div>
            </form>
          </div>

          <!-- Change Password -->
          <div class="card">
            <div class="section-title">Change Password</div>
            <form id="changePasswordForm" novalidate>
              <div class="form-group">
                <label class="form-label">New Password</label>
                <div class="input-wrap">
                  <input type="password" id="newPassword" class="form-input" placeholder="Choose a new password"/>
                  <button type="button" class="toggle-password" data-target="newPassword">👁</button>
                </div>
                <div class="strength-meter mt-8">
                  <div class="strength-bars" id="pStrengthBars">
                    <div class="strength-bar"></div>
                    <div class="strength-bar"></div>
                    <div class="strength-bar"></div>
                    <div class="strength-bar"></div>
                  </div>
                  <div class="strength-label" id="pStrengthLabel"><span>Password strength</span><span></span></div>
                  <div class="rules-list" id="pRulesList"></div>
                </div>
              </div>
              <button type="submit" class="btn btn-primary btn-sm mt-8">Update Password</button>
            </form>
          </div>

          <!-- Danger Zone -->
          <div class="card">
            <div class="section-title" style="color:var(--danger)">Danger Zone</div>
            <p style="font-size:.85rem;color:var(--text-2);margin-bottom:16px">
              Permanently delete your account and all associated data. This cannot be undone.
            </p>
            <button class="btn btn-danger" id="deleteAccountBtn">🗑 Delete My Account</button>
          </div>
        </div>
      </div>
    `;

    setTimeout(initProfilePage, 50);
    return html;
  };

  const initProfilePage = () => {
    // Edit toggle
    const editBtn = document.getElementById('editProfileBtn');
    const cancelBtn = document.getElementById('cancelEditBtn');
    const saveArea = document.getElementById('profileSaveArea');
    const editableFields = ['pFirstName', 'pLastName', 'pEmail', 'pRole'];

    editBtn?.addEventListener('click', () => {
      editableFields.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.disabled = false;
      });
      saveArea.style.display = 'flex';
      saveArea.style.gap = '8px';
      editBtn.style.display = 'none';
    });

    cancelBtn?.addEventListener('click', () => {
      editableFields.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.disabled = true;
      });
      saveArea.style.display = 'none';
      editBtn.style.display = '';
    });

    document.getElementById('profileForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const user = DOM.store.get('user');
      user.firstName = document.getElementById('pFirstName').value;
      user.lastName = document.getElementById('pLastName').value;
      user.email = document.getElementById('pEmail').value;
      user.role = document.getElementById('pRole').value;
      DOM.store.set('user', user);
      DOM.store.logAction('updated profile');
      DOM.toast.success('Profile Updated!', 'Your changes have been saved.');
      cancelBtn?.click();
      // Update avatar initials
      const initials = `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase();
      const av = document.getElementById('avatarEl');
      if (av) av.textContent = initials;
    });

    // Password toggle
    document.querySelectorAll('.toggle-password').forEach(btn => {
      btn.addEventListener('click', () => {
        const input = document.getElementById(btn.dataset.target);
        input.type = input.type === 'password' ? 'text' : 'password';
        btn.textContent = input.type === 'password' ? '👁' : '🙈';
      });
    });

    // Password strength
    document.getElementById('newPassword')?.addEventListener('input', (e) => {
      DOM.updateStrengthUI(e.target.value,
        document.getElementById('pStrengthBars'),
        document.getElementById('pStrengthLabel'),
        document.getElementById('pRulesList')
      );
    });

    document.getElementById('changePasswordForm')?.addEventListener('submit', (e) => {
      e.preventDefault();
      const pw = document.getElementById('newPassword')?.value;
      const { score } = Validator.passwordStrength(pw || '');
      if (!pw || score < 2) {
        DOM.toast.error('Password Too Weak', 'Please choose a stronger password.');
        return;
      }
      DOM.toast.success('Password Updated!', 'Your new password has been saved.');
      document.getElementById('newPassword').value = '';
      DOM.updateStrengthUI('', document.getElementById('pStrengthBars'),
        document.getElementById('pStrengthLabel'), document.getElementById('pRulesList'));
    });

    // Logout
    document.getElementById('logoutBtn')?.addEventListener('click', () => {
      DOM.store.clear();
      DOM.toast.info('Signed Out', 'See you next time!');
      setTimeout(() => Router.navigate('/'), 1000);
    });

    // Delete account
    document.getElementById('deleteAccountBtn')?.addEventListener('click', () => {
      if (confirm('Are you sure? This will permanently delete your account.')) {
        DOM.store.clear();
        DOM.toast.warn('Account Deleted', 'Your account has been removed.');
        setTimeout(() => Router.navigate('/'), 1200);
      }
    });
  };

  /* ══════════════════════════════════
     DASHBOARD PAGE
  ══════════════════════════════════ */
  const dashboard = async () => {
    const user = DOM.store.get('user');
    const name = user ? user.firstName : 'Guest';
    const log = DOM.store.get('sessionLog') || [];

    const activityColors = { 'navigated to /': 'blue', 'registered': 'green', 'logged in': 'green', 'updated profile': 'blue', default: 'warn' };
    const activityHtml = log.slice(0, 6).map((entry, i) => {
      const color = activityColors[entry.action] || activityColors.default;
      const time = new Date(entry.time).toLocaleTimeString();
      return `
        <li class="activity-item" style="animation-delay:${i * 60}ms">
          <span class="activity-dot ${color}"></span>
          <div>
            <div class="activity-text">${entry.action.charAt(0).toUpperCase() + entry.action.slice(1)}</div>
            <div class="activity-time">${time}</div>
          </div>
        </li>
      `;
    }).join('') || `<li class="activity-item"><span class="activity-dot blue"></span><div><div class="activity-text">No activity yet</div></div></li>`;

    const barHeights = [35, 55, 40, 70, 60, 85, 65, 90, 75, 80, 95, 70];
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const barsHtml = barHeights.map((h, i) => `
      <div class="chart-bar" style="height:${h}%">
        <div class="bar-tip">${months[i]}: ${Math.round(h * 1.2)}</div>
      </div>
    `).join('');

    const html = `
      <div class="dashboard">
        <div class="dash-header">
          <div>
            <div class="hero-badge" style="margin-bottom:10px">📊 Live Dashboard</div>
            <h1 class="dash-title">Good ${getGreeting()}, ${name}! 👋</h1>
            <p class="dash-subtitle">${new Date().toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}</p>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a href="#/profile" data-route="/profile" class="btn btn-ghost btn-sm">👤 Profile</a>
            ${user ? '<button class="btn btn-danger btn-sm" id="dashLogout">Sign Out</button>' : '<a href="#/register" data-route="/register" class="btn btn-primary btn-sm">Get Started →</a>'}
          </div>
        </div>

        <div class="metrics-grid">
          <div class="metric-card">
            <span class="metric-icon">📋</span>
            <div class="metric-value" data-count="247">0</div>
            <div class="metric-label">Forms Processed</div>
            <div class="metric-trend trend-up">↑ 12% this month</div>
          </div>
          <div class="metric-card">
            <span class="metric-icon">✅</span>
            <div class="metric-value" data-count-pct="98">0</div>
            <div class="metric-label">Validation Success Rate</div>
            <div class="metric-trend trend-up">↑ 3% vs last week</div>
          </div>
          <div class="metric-card">
            <span class="metric-icon">⚡</span>
            <div class="metric-value" data-count="12">0</div>
            <div class="metric-label">Active Rules</div>
            <div class="metric-trend" style="color:var(--text-3)">Real-time validation</div>
          </div>
          <div class="metric-card">
            <span class="metric-icon">🗺️</span>
            <div class="metric-value" data-count="5">0</div>
            <div class="metric-label">SPA Routes</div>
            <div class="metric-trend" style="color:var(--text-3)">Zero page reloads</div>
          </div>
        </div>

        <div class="dash-grid">
          <!-- Activity -->
          <div class="card">
            <div class="section-title">Session Activity</div>
            <ul class="activity-list" id="activityList">
              ${activityHtml}
            </ul>
            <button class="btn btn-ghost btn-sm mt-16" id="clearLogBtn">Clear Log</button>
          </div>

          <!-- Chart -->
          <div class="card">
            <div class="section-title">Monthly Submissions</div>
            <div class="chart-area">
              <div class="chart-bars">${barsHtml}</div>
            </div>
            <div style="display:flex;gap:12px;margin-top:12px;flex-wrap:wrap">
              <button class="btn btn-ghost btn-sm" id="animateChartBtn">▶ Animate</button>
              <button class="btn btn-ghost btn-sm" id="shuffleChartBtn">🔀 Randomize</button>
            </div>
          </div>
        </div>

        <!-- Quick Actions -->
        <div class="card" style="margin-top:20px">
          <div class="section-title">Quick Actions</div>
          <div style="display:flex;gap:12px;flex-wrap:wrap">
            <a href="#/register" data-route="/register" class="btn btn-ghost btn-sm">📝 New Registration</a>
            <a href="#/login" data-route="/login" class="btn btn-ghost btn-sm">🔐 Login Demo</a>
            <a href="#/profile" data-route="/profile" class="btn btn-ghost btn-sm">👤 Edit Profile</a>
            <button class="btn btn-ghost btn-sm" id="demoToastBtn">🍞 Show Toast</button>
            <button class="btn btn-ghost btn-sm" id="addActivityBtn">➕ Add Activity</button>
          </div>
        </div>
      </div>
    `;

    setTimeout(initDashboard, 50);
    return html;
  };

  const initDashboard = () => {
    // Animate counters
    document.querySelectorAll('[data-count]').forEach(el => {
      DOM.onVisible(el, (node) => DOM.animateCount(node, 0, parseInt(node.dataset.count), 1200));
    });
    document.querySelectorAll('[data-count-pct]').forEach(el => {
      DOM.onVisible(el, (node) => DOM.animateCount(node, 0, parseInt(node.dataset.countPct || node.dataset.countPct), 1200, '%'));
    });
    // fix for data-count-pct
    document.querySelectorAll('.metric-value').forEach(el => {
      if (el.dataset.countPct) DOM.animateCount(el, 0, parseInt(el.dataset.countPct), 1400, '%');
    });

    // Clear log
    document.getElementById('clearLogBtn')?.addEventListener('click', () => {
      DOM.store.set('sessionLog', []);
      const list = document.getElementById('activityList');
      if (list) list.innerHTML = `<li class="activity-item"><span class="activity-dot blue"></span><div><div class="activity-text">Log cleared</div></div></li>`;
      DOM.toast.info('Log Cleared', 'Session activity has been reset.');
    });

    // Chart animate
    document.getElementById('animateChartBtn')?.addEventListener('click', () => {
      document.querySelectorAll('.chart-bar').forEach((bar, i) => {
        setTimeout(() => {
          bar.style.transition = 'height 0.6s cubic-bezier(.4,0,.2,1)';
          bar.style.height = '0';
          setTimeout(() => { bar.style.height = bar.style.height || '50%'; }, 50);
        }, i * 40);
      });
    });

    // Chart shuffle
    document.getElementById('shuffleChartBtn')?.addEventListener('click', () => {
      document.querySelectorAll('.chart-bar').forEach(bar => {
        const h = Math.round(20 + Math.random() * 75);
        bar.style.transition = 'height 0.5s ease';
        bar.style.height = h + '%';
        bar.querySelector('.bar-tip').textContent = bar.querySelector('.bar-tip').textContent.split(':')[0] + ': ' + Math.round(h * 1.2);
      });
    });

    // Demo toast
    const toastTypes = ['success', 'error', 'warn', 'info'];
    let toastIdx = 0;
    document.getElementById('demoToastBtn')?.addEventListener('click', () => {
      const type = toastTypes[toastIdx % 4];
      const msgs = {
        success: ['Validation Passed!', 'All fields look great.'],
        error:   ['Validation Failed', 'Please check your input.'],
        warn:    ['Weak Password', 'Consider a stronger password.'],
        info:    ['Pro Tip', 'Use keyboard shortcuts for faster input.'],
      };
      DOM.toast[type](...msgs[type]);
      toastIdx++;
    });

    // Add activity
    const actions = ['ran validation', 'navigated to /profile', 'toggled theme', 'submitted form', 'changed password'];
    let aIdx = 0;
    document.getElementById('addActivityBtn')?.addEventListener('click', () => {
      DOM.store.logAction(actions[aIdx % actions.length]);
      aIdx++;
      const list = document.getElementById('activityList');
      const entry = DOM.store.get('sessionLog')[0];
      const item = document.createElement('li');
      item.className = 'activity-item';
      item.innerHTML = `
        <span class="activity-dot green"></span>
        <div>
          <div class="activity-text">${entry.action.charAt(0).toUpperCase() + entry.action.slice(1)}</div>
          <div class="activity-time">${new Date(entry.time).toLocaleTimeString()}</div>
        </div>
      `;
      list?.insertBefore(item, list.firstChild);
      if (list?.children.length > 8) list.lastChild?.remove();
    });

    // Logout from dashboard
    document.getElementById('dashLogout')?.addEventListener('click', () => {
      DOM.store.clear();
      DOM.toast.info('Signed Out', 'Come back soon!');
      setTimeout(() => Router.navigate('/'), 900);
    });
  };

  const getGreeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'morning';
    if (h < 17) return 'afternoon';
    return 'evening';
  };

  /* ══════════════════════════════════
     404 PAGE
  ══════════════════════════════════ */
  const notFound = () => `
    <div class="not-found">
      <div>
        <h1>404</h1>
        <p>The page you're looking for doesn't exist.</p>
        <a href="#/" data-route="/" class="btn btn-primary">← Go Home</a>
      </div>
    </div>
  `;

  return { home, register, login, profile, dashboard, notFound };
})();
