/**
 * FormForge — Validator Engine
 * A composable, rule-based validation library
 */

const Validator = (() => {

  /* ─── RULES ─── */
  const rules = {

    required: (val) => ({
      valid: val.trim().length > 0,
      message: 'This field is required.'
    }),

    minLength: (val, min) => ({
      valid: val.length >= min,
      message: `Must be at least ${min} characters.`
    }),

    maxLength: (val, max) => ({
      valid: val.length <= max,
      message: `Must be no more than ${max} characters.`
    }),

    email: (val) => ({
      valid: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val),
      message: 'Please enter a valid email address.'
    }),

    username: (val) => ({
      valid: /^[a-zA-Z0-9_.-]{3,20}$/.test(val),
      message: 'Username: 3–20 chars, letters/digits/._- only.'
    }),

    phone: (val) => ({
      valid: /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/.test(val.replace(/\s/g, '')),
      message: 'Enter a valid phone number.'
    }),

    url: (val) => {
      try { new URL(val.startsWith('http') ? val : `https://${val}`); return { valid: true }; }
      catch { return { valid: false, message: 'Enter a valid URL.' }; }
    },

    match: (val, target, targetLabel = 'passwords') => ({
      valid: val === target,
      message: `The ${targetLabel} do not match.`
    }),

    noSpaces: (val) => ({
      valid: !/\s/.test(val),
      message: 'No spaces allowed.'
    }),

    lettersOnly: (val) => ({
      valid: /^[a-zA-Z\s]+$/.test(val),
      message: 'Letters only please.'
    }),

    numeric: (val) => ({
      valid: /^\d+$/.test(val),
      message: 'Numbers only please.'
    }),

    alphanumeric: (val) => ({
      valid: /^[a-zA-Z0-9]+$/.test(val),
      message: 'Alphanumeric characters only.'
    }),

    checked: (val) => ({
      valid: val === true,
      message: 'You must accept this.'
    }),

    minTags: (tags, min) => ({
      valid: tags.length >= min,
      message: `Add at least ${min} tag${min > 1 ? 's' : ''}.`
    }),
  };

  /* ─── PASSWORD STRENGTH ─── */
  const passwordStrength = (password) => {
    const checks = {
      length:    password.length >= 8,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number:    /\d/.test(password),
      special:   /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password),
      long:      password.length >= 12,
    };

    const passed = Object.values(checks).filter(Boolean).length;

    let score, label, colorClass;
    if (password.length === 0) {
      score = 0; label = ''; colorClass = '';
    } else if (passed <= 2) {
      score = 1; label = 'Weak'; colorClass = 'active-1';
    } else if (passed === 3) {
      score = 2; label = 'Fair'; colorClass = 'active-2';
    } else if (passed === 4 || passed === 5) {
      score = 3; label = 'Strong'; colorClass = 'active-3';
    } else {
      score = 4; label = 'Very Strong'; colorClass = 'active-4';
    }

    return { score, label, colorClass, checks };
  };

  /* ─── VALIDATE FIELD ─── */
  const validateField = (value, fieldRules) => {
    for (const rule of fieldRules) {
      const { name, args = [] } = typeof rule === 'string'
        ? { name: rule }
        : rule;

      const fn = rules[name];
      if (!fn) continue;

      const result = fn(value, ...args);
      if (!result.valid) return { valid: false, message: result.message };
    }
    return { valid: true, message: '' };
  };

  /* ─── VALIDATE FORM ─── */
  const validateForm = (schema) => {
    const errors = {};
    let isValid = true;

    for (const [field, { value, rules: fieldRules }] of Object.entries(schema)) {
      const result = validateField(value, fieldRules);
      if (!result.valid) {
        errors[field] = result.message;
        isValid = false;
      }
    }

    return { isValid, errors };
  };

  /* ─── REAL-TIME FIELD BINDER ─── */
  const bindField = (input, fieldRules, options = {}) => {
    const {
      onValid = () => {},
      onInvalid = () => {},
      msgEl = null,
      iconOk = null,
      iconErr = null,
      showOnBlur = false,
    } = options;

    let touched = false;

    const run = () => {
      if (showOnBlur && !touched) return;
      const val = input.type === 'checkbox' ? input.checked : input.value;
      const { valid, message } = validateField(val, fieldRules);

      input.classList.toggle('valid', valid);
      input.classList.toggle('invalid', !valid);
      if (iconOk) iconOk.style.opacity = valid ? '1' : '0';
      if (iconErr) iconErr.style.opacity = (!valid && touched) ? '1' : '0';

      if (msgEl) {
        msgEl.textContent = valid ? '' : message;
        msgEl.className = `field-msg ${valid ? '' : 'error-msg show'}`;
      }

      valid ? onValid(val) : onInvalid(val, message);
      return valid;
    };

    input.addEventListener('input', run);
    input.addEventListener('blur', () => { touched = true; run(); });
    return { validate: run };
  };

  return { rules, passwordStrength, validateField, validateForm, bindField };
})();
