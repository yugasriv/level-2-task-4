/**
 * FormForge — Client-Side Router
 * Hash-based SPA routing with middleware support
 */

const Router = (() => {

  const routes = new Map();
  const middleware = [];
  let notFoundHandler = () => `<div class="not-found"><h1>404</h1><p>Page not found.</p><a href="#/" class="btn btn-ghost">Go Home</a></div>`;
  let beforeEach = null;
  let afterEach = null;
  const history = [];

  /* ─── REGISTER ROUTE ─── */
  const register = (path, handler, meta = {}) => {
    routes.set(path, { handler, meta });
  };

  /* ─── NAVIGATE ─── */
  const navigate = (path) => {
    window.location.hash = path;
  };

  /* ─── CURRENT ROUTE ─── */
  const currentPath = () => {
    const hash = window.location.hash;
    return hash ? hash.slice(1) : '/';
  };

  /* ─── RESOLVE ─── */
  const resolve = async () => {
    const path = currentPath();
    const route = routes.get(path) || routes.get('*');

    // Update nav active state
    document.querySelectorAll('[data-route]').forEach(link => {
      link.classList.toggle('active', link.dataset.route === path);
    });

    const app = document.getElementById('app');
    if (!app) return;

    // Before hook
    if (beforeEach) {
      const canProceed = await beforeEach(path, route?.meta || {});
      if (!canProceed) return;
    }

    // Render
    const content = route
      ? await route.handler(path)
      : notFoundHandler(path);

    // Page transition
    app.innerHTML = '';
    const wrapper = document.createElement('div');
    wrapper.className = 'page';
    wrapper.innerHTML = typeof content === 'string' ? content : '';
    if (content instanceof Node) wrapper.appendChild(content);
    app.appendChild(wrapper);

    // Track
    history.push({ path, time: Date.now() });
    DOM.store.logAction(`navigated to ${path}`);

    // After hook
    if (afterEach) afterEach(path, route?.meta || {});

    // Scroll top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  /* ─── GUARDS ─── */
  const authGuard = (path, meta) => {
    if (meta.requiresAuth && !DOM.store.get('user')) {
      DOM.toast.warn('Login Required', 'Please sign in to access that page.');
      navigate('/login');
      return false;
    }
    return true;
  };

  /* ─── INIT ─── */
  const init = (options = {}) => {
    beforeEach = options.beforeEach || authGuard;
    afterEach = options.afterEach || null;

    window.addEventListener('hashchange', resolve);
    window.addEventListener('load', resolve);

    // Intercept data-route links
    document.addEventListener('click', (e) => {
      const link = e.target.closest('[data-route]');
      if (link) {
        e.preventDefault();
        navigate(link.dataset.route);
      }
    });

    return { register, navigate, currentPath, getHistory: () => [...history] };
  };

  return { register, navigate, currentPath, init, getHistory: () => [...history] };
})();
